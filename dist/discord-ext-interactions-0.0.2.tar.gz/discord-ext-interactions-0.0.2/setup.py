from setuptools import setup

setup(
    name='discord-ext-interactions',
    version='0.0.2',
    packages=['discord.ext.interactions'],
    url='https://github.com/dragdev-studios/interactions-python',
    license='MIT',
    author='EEKIM10',
    author_email='eek@clicksminuteper.net',
    description='Simple, quick module that handles discord interactions'
)
